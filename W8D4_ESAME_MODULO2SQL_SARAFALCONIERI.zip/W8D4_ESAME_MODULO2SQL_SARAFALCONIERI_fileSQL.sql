-- CREAZIONE DELLE TABELLE --
-- Tabella Category
CREATE TABLE Category (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(50) NOT NULL
);

-- Tabella Product
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50) NOT NULL,
    CategoryID INT,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);

-- Tabella Region
CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(50) NOT NULL
);

-- Tabella State
CREATE TABLE State (
    StateID INT PRIMARY KEY,
    StateName VARCHAR(50) NOT NULL,
    RegionID INT NOT NULL,
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Tabella Sales
CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    ProductID INT NOT NULL,
    StateID INT NOT NULL,
    OrderDate DATE NOT NULL,
    OrderQuantity INT NOT NULL,
    Total DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (StateID) REFERENCES State(StateID)
);

-- POPOLAZIONE DELLE TABELLE --

-- Popolare la tabella Category
INSERT INTO Category (CategoryID, CategoryName)
VALUES 
(1, 'Educational Toys'),
(2, 'Outdoor Games'),
(3, 'Board Games'),
(4, 'Children Clothing');

-- Popolare la tabella Product
INSERT INTO Product (ProductID, ProductName, CategoryID)
VALUES 
(1, 'Junior Chemistry Set', 1),
(2, 'Kids Bicycle', 2),
(3, 'Electric Scooter', 2),
(4, '500-piece Puzzle', 3),
(5, 'Superhero T-shirt', 4);

-- Popolare la tabella Region
INSERT INTO Region (RegionID, RegionName)
VALUES 
(1, 'Western Europe'),
(2, 'Southern Europe'),
(3, 'North America');

-- Popolare la tabella State
INSERT INTO State (StateID, StateName, RegionID)
VALUES 
(1, 'France', 1),
(2, 'Germany', 1),
(3, 'Italy', 2),
(4, 'Spain', 2),
(5, 'United States', 3);

-- Popolare la tabella Sales
INSERT INTO Sales (SaleID, ProductID, StateID, OrderDate, OrderQuantity, Total)
VALUES 
(1, 1, 1, '2023-01-01', 20, 400.00), -- Vendita in France
(2, 2, 3, '2023-01-10', 15, 1500.00), -- Vendita in Italy
(3, 3, 4, '2023-01-15', 10, 3000.00), -- Vendita in Spain
(4, 4, 2, '2023-01-20', 8, 160.00), -- Vendita in Germany
(5, 5, 5, '2023-01-25', 12, 240.00); -- Vendita in United States


-- 1)	Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).

-- Verifica univocità della PK nella tabella Category
SELECT CategoryID, COUNT(*) AS Count
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

-- Verifica univocità della PK nella tabella Product
SELECT ProductID, COUNT(*) AS Count
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

-- Verifica univocità della PK nella tabella Region
SELECT RegionID, COUNT(*) AS Count
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

-- Verifica univocità della PK nella tabella State
SELECT StateID, COUNT(*) AS Count
FROM State
GROUP BY StateID
HAVING COUNT(*) > 1;

-- Verifica univocità della PK nella tabella Sales
SELECT SaleID, COUNT(*) AS Count
FROM Sales
GROUP BY SaleID
HAVING COUNT(*) > 1;


-- 2) Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
SELECT 
    s.SaleID AS DocumentCode,
    s.OrderDate AS OrderDate,
    p.ProductName AS ProductName,
    c.CategoryName AS ProductCategory,
    st.StateName AS StateName,
    reg.RegionName AS RegionName,
    CASE
        WHEN DATEDIFF(CURDATE(), s.OrderDate) > 180 THEN 'TRUE'
        ELSE 'FALSE'
    END AS MoreThan180Days
FROM 
    Sales s
LEFT JOIN 
    Product p ON s.ProductID = p.ProductID
LEFT JOIN 
    Category c ON p.CategoryID = c.CategoryID
LEFT JOIN 
    State st ON s.StateID = st.StateID
LEFT JOIN 
    Region reg ON st.RegionID = reg.RegionID;

SELECT OrderDate, DATEDIFF(CURDATE(), OrderDate) as Datadiff 
FROM sales;


-- 3)	Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto.

-- Inserisco altri valori per ottenere un risultato più coerente con l'esercizio
-- Aggiungere vendite per il 2022
INSERT INTO Sales (SaleID, ProductID, StateID, OrderDate, OrderQuantity, Total)
VALUES 
(6, 1, 1, '2022-02-15', 25, 500.00),
(7, 2, 3, '2022-05-10', 10, 1000.00),
(8, 3, 4, '2022-08-25', 15, 3000.00);

-- Procedo con l'esercizio
SELECT
    s.ProductID AS ProductCode,
    SUM(s.OrderQuantity) AS TotalSold,
    SUM(s.Total) AS TotalAmount -- Calcola il totale venduto in termini di importo
FROM 
    Sales s
WHERE 
    YEAR(s.OrderDate) = (
        SELECT MAX(YEAR(OrderDate))
        FROM Sales
    )
GROUP BY 
    s.ProductID
HAVING 
    SUM(s.OrderQuantity) > (
        SELECT 
            AVG(OrderQuantity)
        FROM 
            Sales
        WHERE 
            YEAR(OrderDate) = (
                SELECT MAX(YEAR(OrderDate))
                FROM Sales
            )
    );


-- 4)	Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
SELECT 
    p.ProductName AS ProductName,
    SUM(s.Total) AS TotalAmount,
    YEAR(s.OrderDate) AS Year
FROM 
    Sales s
INNER JOIN 
    Product p ON s.ProductID = p.ProductID
GROUP BY 
    p.ProductName, YEAR(s.OrderDate)
ORDER BY 
    p.ProductName, Year;

-- 5)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT
    st.StateName AS StateName,
    SUM(s.Total) AS TotalAmount,
    YEAR(s.OrderDate) AS Year
FROM 
    Sales s
LEFT JOIN 
    State st ON s.StateID = st.StateID
GROUP BY 
    st.StateName, YEAR(s.OrderDate)
ORDER BY 
    YEAR(s.OrderDate) ASC,
    SUM(s.Total) DESC;
    

-- 6)	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
SELECT
    c.CategoryName AS CategoryName,
    SUM(s.OrderQuantity) AS TotalSold
FROM 
    Sales s
INNER JOIN 
    Product p ON s.ProductID = p.ProductID
INNER JOIN 
    Category c ON c.CategoryID = p.CategoryID
GROUP BY 
    c.CategoryName
ORDER BY 
    SUM(s.OrderQuantity) DESC;


-- 7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.
-- Per rendere l'esercizio piu coerente, dato che non ci sono prodotti invenduti, ne inserisco altri che non compaiono nelle vendite, così da ottenere in output

-- Aggiungere nuovi prodotti senza vendite
INSERT INTO Product (ProductID, ProductName, CategoryID)
VALUES 
(6, 'Toy Car', 2),       -- Categoria: Outdoor Games
(7, 'Puzzle Book', 3);   -- Categoria: Board Games

-- Ora procedo con l'esercizio. Opzione 1 di risoluzione:
SELECT
p.ProductName as ProductName,
SUM(s.OrderQuantity) as TotalSold
FROM product p
LEFT JOIN sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductName
HAVING SUM(s.OrderQuantity) IS NULL;

-- Ora procedo con l'esercizio. Opzione 2 di risoluzione:
SELECT 
    p.ProductName AS ProductName
FROM 
    product p
WHERE 
    p.ProductID NOT IN (
        SELECT DISTINCT s.ProductID 
        FROM Sales s
    );


-- 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)
CREATE VIEW ProductView AS
SELECT
p.ProductID as ProductID,
p.ProductName as ProductName,
c.CategoryName as ProductCategory
FROM product p
INNER JOIN category c ON p.CategoryID = c.CategoryID;

-- 9)	Creare una vista per le informazioni geografiche
CREATE VIEW GeographicView AS
SELECT
st.StateID as StateID,
st.StateName as StateName,
reg.RegionID as RegionID,
reg.RegionName as RegionName
FROM state st
INNER JOIN region reg ON st.RegionID = reg.RegionID;
