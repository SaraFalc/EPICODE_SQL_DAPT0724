
-- ESERCIZIO 1

CREATE VIEW Product as (
SELECT
	p.ProductKey,
    p.EnglishProductName as ProductName,
	sub.ProductSubcategoryKey,
    sub.EnglishProductSubcategoryName as SubcategoryName
FROM dimproduct p
INNER JOIN dimproductsubcategory sub
ON p.ProductSubcategoryKey = sub.ProductSubcategoryAlternateKey);

-- ESERCIZIO 2
CREATE VIEW Reseller as (
SELECT 
	res.ResellerKey,
    res.ResellerName,
    geo.City,
    geo.EnglishCountryRegionName AS Region
FROM dimreseller res
INNER JOIN dimgeography geo
ON res.GeographyKey = geo.GeographyKey);

-- ESERCIZIO 3
CREATE VIEW Sales as (
SELECT 
	ProductKey,
    ResellerKey,
    OrderDate as DataOrdine,
    SalesOrderNumber as CodiceDocumento,
    SalesOrderLineNumber as RigaCorpoDocumento,
    OrderQuantity as QuantitàVenduta,
    SalesAmount as ImportoTotale,
    (SalesAmount-TotalProductCost) as Profitto
FROM factresellersales);

-- ESERCIZIO 4: vedi foglio xls

